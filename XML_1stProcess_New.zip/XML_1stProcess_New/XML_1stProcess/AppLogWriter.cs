﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XML_1stProcess
{
    class AppLogWriter
    {

        private static AppLogWriter instance;
        private static Queue<AppLog> logQueue;

        //Modified by Somesh Chandra
       // public static string logDir = Path.GetDirectoryName(Directory.GetParent(Environment.CurrentDirectory).ToString()) + @"\Logs\";
        private static string logDir = AppDomain.CurrentDomain.BaseDirectory.ToString() + @"Logs\";
        //AppDomain.CurrentDomain.BaseDirectory.ToString() + @"Logs\";
        // public static string logDir;
        //AppDomain.CurrentDomain.BaseDirectory.ToString();
        private static string logFile = "AppLog";
        // public static int maxLogAge = int.Parse(ini.IniReadValue("AppLogWriterSetting", "AppQueueSize"));
        // public static int queueSize = int.Parse(ini.IniReadValue("AppLogWriterSetting", "AppLogAge"));
        private static int maxLogAge = int.Parse(ConfigurationManager.AppSettings["AppLogAge"].ToString());
        private static int queueSize = int.Parse(ConfigurationManager.AppSettings["AppQueueSize"].ToString());
        private static DateTime LastFlushed = DateTime.Now;

        /// <summary>
        /// Private constructor to prevent instance creation
        /// </summary>
        private AppLogWriter() { }

        /// <summary>
        /// An LogWriter instance that exposes a single instance
        /// </summary>
        public static AppLogWriter Instance
        {
            get
            {
                // If the instance is null then create one and init the Queue
                if (instance == null)
                {
                    instance = new AppLogWriter();
                    logQueue = new Queue<AppLog>();
                }
                return instance;
            }
        }

        /// <summary>
        /// The single instance method that writes to the log file
        /// </summary>
        /// <param name="message">The message to write to the log</param>
        public void WriteToLog(string message)
        {
            // Lock the queue while writing to prevent contention for the log file
            lock (logQueue)
            {
                // Create the entry and push to the Queue
                AppLog logEntry = new AppLog(message);
                logQueue.Enqueue(logEntry);

                // If we have reached the Queue Size then flush the Queue
                if (logQueue.Count >= queueSize || DoPeriodicFlush())
                {
                    FlushLog();
                }
            }
        }

        private bool DoPeriodicFlush()
        {
            TimeSpan logAge = DateTime.Now - LastFlushed;
            if (logAge.TotalSeconds >= maxLogAge)
            {
                LastFlushed = DateTime.Now;
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Flushes the Queue to the physical log file
        /// </summary>
        private void FlushLog()
        {
            while (logQueue.Count > 0)
            {
                AppLog entry = logQueue.Dequeue();
                //checking the current directory exsits or not, if not add
                if (!Directory.Exists(logDir))
                    Directory.CreateDirectory(logDir);

                string logPath = logDir + "\\" + entry.LogDate + "_" + logFile;
                // code added By Rajeev Mishra/////
                float N = 1; //Log File size in MB
                FileInfo LFileInfo = new FileInfo(logPath);
                if (File.Exists(logPath))
                {
                    if ((LFileInfo.Length) > 1048576 * N)
                    {
                        //Added By Rakesh On 31/05/2018

                        string lBackName = logDir.Substring(logDir.Length - 4, 4);

                        bool folderExists = Directory.Exists(logDir + "\\" + lBackName + "BackupAppLogFolder");
                        if (!folderExists)
                            Directory.CreateDirectory(logDir + "\\" + lBackName + "BackupAppLogFolder");
                        string fileLocMove = logDir + "\\" + @"" + lBackName + "BackupAppLogFolder\\" + "BAK" + DateTime.Now.ToFileTime().ToString() + "_" + logFile;
                        File.Move(logPath, fileLocMove);
                        using (FileStream fs = File.Open(logPath, FileMode.Create, FileAccess.Write))
                        {
                            using (StreamWriter log = new StreamWriter(fs))
                            {
                                log.WriteLine(string.Format("{0}\t{1}", entry.LogTime, entry.Message));
                            }
                        }
                    }
                    else
                    {
                        // This could be optimised to prevent opening and closing the file for each write
                        using (FileStream fs = File.Open(logPath, FileMode.Append, FileAccess.Write))
                        {
                            using (StreamWriter log = new StreamWriter(fs))
                            {
                                log.WriteLine(string.Format("{0}\t{1}", entry.LogTime, entry.Message));
                            }
                        }
                    }

                }
                else
                {
                    // This could be optimised to prevent opening and closing the file for each write
                    using (FileStream fs = File.Open(logPath, FileMode.Append, FileAccess.Write))
                    {
                        using (StreamWriter log = new StreamWriter(fs))
                        {
                            log.WriteLine(string.Format("{0}\t{1}", entry.LogTime, entry.Message));
                        }
                    }
                }
            }
        }
    }

    /// <summary>
    /// A Log class to store the message and the Date and Time the log entry was created
    /// </summary>
    public class AppLog
    {
        public string Message { get; set; }
        public string LogTime { get; set; }
        public string LogDate { get; set; }

        public AppLog(string message)
        {
            Message = message;
            LogDate = DateTime.Now.ToString("yyyy-MM-dd");
            LogTime = DateTime.Now.ToString("hh:mm:ss.fff tt");
        }
    }
}
