﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XML_1stProcess
{
    public partial class jslip_seller_buyer
    {
        public string reg_no { get; set; }
        public string prop_no { get; set; }
        public string survey_no { get; set; }
        public string surnoc { get; set; }
        public string hissa_no { get; set; }
        public string total_area { get; set; }
        public string unit_of_measure { get; set; }
        public string party_no { get; set; }
        public string party_name { get; set; }
        public string fat_hus_name { get; set; }
        public string GPA_name { get; set; }
        public string joint_with_prev { get; set; }
        public string liabilities { get; set; }
        public string seller_buyer { get; set; }
        public string address { get; set; }
        public Nullable<int> uniq_id { get; set; }
        public Nullable<bool> sdc_rep_col_flg { get; set; }
        public Nullable<System.Guid> sdc_rep_col_id_u { get; set; }
        public System.Guid jslip_seller_buyer_GUID { get; set; }
        public Nullable<System.DateTime> InsertedDate { get; set; }
        public Nullable<System.DateTime> UpdatedDate { get; set; }
        public string reg_no_UC { get; set; }
        public string prop_no_UC { get; set; }
        public string survey_no_UC { get; set; }
        public string surnoc_UC { get; set; }
        public string hissa_no_UC { get; set; }
        public string total_area_UC { get; set; }
        public string unit_of_measure_UC { get; set; }
        public string party_no_UC { get; set; }
        public string party_name_UC { get; set; }
        public string fat_hus_name_UC { get; set; }
        public string GPA_name_UC { get; set; }
        public string joint_with_prev_UC { get; set; }
        public string liabilities_UC { get; set; }
        public string seller_buyer_UC { get; set; }
        public string address_UC { get; set; }
        public Nullable<int> isconverted { get; set; }
    }
}
