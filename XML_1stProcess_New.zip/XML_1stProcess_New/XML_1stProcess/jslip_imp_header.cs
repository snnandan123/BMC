﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XML_1stProcess
{
    public partial class jslip_imp_header
    {
        public int reg_id { get; set; }
        public string reg_no { get; set; }
        public string taluk_code { get; set; }
        public string taluk_name { get; set; }
        public string hobli_code { get; set; }
        public string hobli_name { get; set; }
        public string village_code { get; set; }
        public string village_name { get; set; }
        public string article_name { get; set; }
        public string exec_date { get; set; }
        public string sro_name { get; set; }
        public string sro_code { get; set; }
        public string cons_amount { get; set; }
        public Nullable<int> appl_no { get; set; }
        public string appl_year { get; set; }
        public string JSlip_Status { get; set; }
        public string Rej_Reason { get; set; }
        public string Rej_Reason_Shir { get; set; }
        public Nullable<int> link_no { get; set; }
        public Nullable<byte> reject_code1 { get; set; }
        public Nullable<byte> reject_code2 { get; set; }
        public Nullable<byte> reject_code3 { get; set; }
        public Nullable<byte> reject_code4 { get; set; }
        public Nullable<byte> reject_code5 { get; set; }
        public int uniq_id { get; set; }
        public string hardcopyreceived_status { get; set; }
        public Nullable<System.DateTime> hardcopyreceived_date { get; set; }
        public string reg_date { get; set; }
        public string New_Old { get; set; }
        public Nullable<System.DateTime> rej_appr_date { get; set; }
        public string deo_login { get; set; }
        public string sir_login { get; set; }
        public string RejectedXML { get; set; }
        public Nullable<bool> sdc_rep_col_flg { get; set; }
        public Nullable<System.Guid> sdc_rep_col_id_u { get; set; }
        public Nullable<System.DateTime> InsertedDate { get; set; }
        public Nullable<System.DateTime> UpdatedDate { get; set; }
        public string reg_no_UC { get; set; }
        public string taluk_code_UC { get; set; }
        public string taluk_name_UC { get; set; }
        public string hobli_code_UC { get; set; }
        public string hobli_name_UC { get; set; }
        public string village_code_UC { get; set; }
        public string village_name_UC { get; set; }
        public string article_name_UC { get; set; }
        public string exec_date_UC { get; set; }
        public string sro_name_UC { get; set; }
        public string sro_code_UC { get; set; }
        public string cons_amount_UC { get; set; }
        public string appl_year_UC { get; set; }
        public string JSlip_Status_UC { get; set; }
        public string Rej_Reason_UC { get; set; }
        public string Rej_Reason_Shir_UC { get; set; }
        public string hardcopyreceived_status_UC { get; set; }
        public string reg_date_UC { get; set; }
        public string New_Old_UC { get; set; }
        public string deo_login_UC { get; set; }
        public string sir_login_UC { get; set; }
        public string RejectedXML_UC { get; set; }
        public Nullable<int> isconverted { get; set; }
    }
}
