﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using Newtonsoft.Json;
using System.Data;
using System.Xml;
using System.Configuration;

namespace XML_1stProcess
{

    public class Program
    {
        Da_class objData = null;
        AppLogWriter FObjappLog = AppLogWriter.Instance;
        public static void Main(string[] args)
        {
            //Da_class objData = new Da_class();
            //string Lpath = ConfigurationManager.AppSettings["FilePath"].ToString();
            //DataSet Lda = objData.getdataset(Lpath);

            Program p = new Program();
            p.Getrecord();
            Console.ReadKey();

            
        }
        
       
        #region GetXml From Physical xml file
        public string Getrecord()
        {
          
            FObjappLog.WriteToLog("Enter Into Getrecord Mehod");
            string LxData = "";
            try
            {
                objData = new Da_class();
                int Rpost = 0;
                Console.WriteLine("\n Record inserting to database - Please Wait...");
                
                objData.ProcessPhysicalData();  // Application 1 Area== Process Old Data Method First

                //-------------------------
                LxData = Rpost + " Record inserted to database";
                Console.WriteLine("\n if in-case some xml reading fail, you should check your error folders..");
                Console.WriteLine("\n Record Successfully inserted to database...");
                FObjappLog.WriteToLog("Record Inserted Successfully");
                Environment.Exit(0);
            }
            catch (Exception ex)
            {
                FObjappLog.WriteToLog("Excpetion in Getrecord Mehod" +ex.Message);
            }
            return LxData;

        }
        #endregion

    }
}
