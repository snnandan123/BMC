﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Collections;
using Com.Cdacindia.Gist.RevConverters;
using Com.Cdacindia.Gist.NetISMAPI;

namespace XML_1stProcess
{
    public class CSUtility
    {

        /// <summary>
        /// Path of the temp Directory
        /// </summary>
        private string FDirectoryPath;
        /// <summary>
        /// Support files directory path
        /// </summary>
        private string FAppDirectory;
        /// <summary>
        /// objects of unicode conversion classes
        /// </summary>
        RevConverter FRConv = new RevConverter();
        Com.Cdacindia.Gist.NetISMAPI.Converter FConv = new Converter();

        /// <summary>
        /// default constructor
        /// </summary>
        public CSUtility()
        {
            FAppDirectory = AppDomain.CurrentDomain.BaseDirectory.ToString() + @"SupportFiles\";
            FDirectoryPath = "RTCPreviewPng";
        }

        /// <summary>
        /// Desgtructor
        /// </summary>
        ~CSUtility()
        {

        }

        public virtual void Dispose()
        {

        }

        /// <summary>
        /// converts the string data to unicode data
        /// </summary>
        /// <param name="pStringData"></param>
        public string ConvertToUnicode(string pStringData)
        {
            return FConv.IsciiToUnicode(FRConv.IsfocToIscii(pStringData, "Kannada"), "KNB");
        }

        /// <summary>
        /// deletes the preview directory
        /// </summary>
        public void DeletePreviewTempDirectory()
        {
            try
            {
                //main directory RTCOldYearPdf
                string Lpath = AppDomain.CurrentDomain.BaseDirectory + FDirectoryPath;
                if (Directory.Exists(Lpath))
                {
                    Directory.Delete((Lpath), true);
                }
            }
            catch (Exception GeneralException)
            {
            }
        }

        #region for unicode to isfoc
        public string GetIsfoc(string strUnicode)
        {
            string toIsFoc;
            string strgISCII;
            Com.Cdacindia.Gist.NetISMAPI.Converter objNetISMAPIConverter;
            Com.Cdacindia.Gist.Converters.Converter objConverter;

            RevConverter objRevConverter;
            try
            {
                objNetISMAPIConverter = new Com.Cdacindia.Gist.NetISMAPI.Converter();
                objConverter = new Com.Cdacindia.Gist.Converters.Converter();
                objRevConverter = new RevConverter();

                strgISCII = objNetISMAPIConverter.UnicodeToIscii(strUnicode);//"ಸದರಿ ಸ್ವತ್ತಿನ ");
                toIsFoc = objConverter.IsciiToIsfoc(strgISCII, "Kannada");
                return toIsFoc;

            }
            catch (Exception e)
            { return "ERROR " + e.Message; }
        }
        #endregion
    }
}
