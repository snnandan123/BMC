﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XML_1stProcess
{
    public partial class jslip_imp_main
    {
        public string sro_code { get; set; }
        public string from_date { get; set; }
        public string to_date { get; set; }
        public Nullable<byte> no_of_jslip { get; set; }
        public Nullable<byte> no_of_ok_jslip { get; set; }
        public int link_no { get; set; }
        public string dst { get; set; }
        public string src { get; set; }
        public Nullable<System.DateTime> ImportedDate { get; set; }
        public string XMLVersion { get; set; }
        public Nullable<bool> sdc_rep_col_flg { get; set; }
        public Nullable<System.Guid> sdc_rep_col_id_u { get; set; }
        public Nullable<System.DateTime> InsertedDate { get; set; }
        public Nullable<System.DateTime> UpdatedDate { get; set; }
        public string sro_code_UC { get; set; }
        public string from_date_UC { get; set; }
        public string to_date_UC { get; set; }
        public string dst_UC { get; set; }
        public string src_UC { get; set; }
        public string XMLVersion_UC { get; set; }
        public Nullable<int> isconverted { get; set; }

        public int cdist1 { get; set; }
        public int ctaluk1 { get; set; }
    }
}
