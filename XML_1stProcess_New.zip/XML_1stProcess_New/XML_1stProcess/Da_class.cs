﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.IO;
using System.Xml;
using System.Security.Cryptography;
using System.Security;
using System.Security.Cryptography.Xml;

namespace XML_1stProcess
{
     public class Da_class
    {

        jslip_imp_main objMain = new jslip_imp_main();
        jslip_imp_header objH = null;
        jslip_seller_buyer objSB = null;
        Jslip_data objdata = new Jslip_data();
        DataTable gDTDataTable = new DataTable();
        string Foldername = "";
        int itr = 0;
       
        CSUtility FObjUtility = null;

      //  int CDist = Convert.ToInt16(ConfigurationManager.AppSettings["CDistCode"].ToString());
       // int CTaluk = Convert.ToInt16(ConfigurationManager.AppSettings["CTalukCode"].ToString());
        string PTS = ConfigurationManager.AppSettings["PTS"].ToString();  //Either production or testing
        AppLogWriter FObjappLog = AppLogWriter.Instance;
       
        DataSet ds = null;
        DataTable dt = null;
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Jslip"].ConnectionString);
        SqlConnection JslipXMLFolder = new SqlConnection(ConfigurationManager.ConnectionStrings["XmlFolder"].ConnectionString);
       


        #region get Record Byid
        public DataSet GetRecordbyid(int rid) //3320448
        {
            try
            {
                string qry = "select RegistrationId,JSlipData from JSlip_Data where RegistrationId =" + rid;
                if (rid == 1)
                {
                    qry = "select top 10 RegistrationId,JSlipData from JSlip_Data";

                }
                con.Open();
                SqlCommand com = new SqlCommand(qry, con);
                SqlDataAdapter da = new SqlDataAdapter(com);

                ds = new DataSet();

                da.Fill(ds);
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                con.Close();
            }

            return ds;

        }
        #endregion

        #region insert or update record in jslipdata table
        public int PostRecord(string cipherText, string planText, int istatus, int? rid, int dst) //3320448
        {
            int result = 0;
            int cdist = dst / 100;
            int ctaluk = dst % 100;

            string status = "";
            string qry = "";
            try
            {

                if (istatus == 0)
                {
                    status = "OLD";

                    qry = "USP_Add_OldData";
                }
                else if (istatus == 1)
                {
                    status = "NEW";

                    qry = "Update JSlip_Data set NewJslipData=@DcJslipData,Status=@Status where RegistrationID=@RegistrationID)";
                }


                if (con.State == ConnectionState.Closed)
                    con.Open();
                SqlCommand com = new SqlCommand(qry, con);
                if (istatus == 0)
                {
                    com.CommandType = CommandType.StoredProcedure;
                    com.Parameters.AddWithValue("@EnJslipData", @cipherText);
                    com.Parameters.AddWithValue("@talukStatus", "OJD");
                    com.Parameters.AddWithValue("@CDist", cdist);
                    com.Parameters.AddWithValue("@CTaluk", ctaluk);
                }

                com.Parameters.AddWithValue("@DcJslipData", @planText);
                com.Parameters.AddWithValue("@Status", @status);
                com.Parameters.AddWithValue("@RegistrationID", rid);   //@CDist, @CTaluk

                result = com.ExecuteNonQuery();


            }
            catch (Exception ex)
            {
                FObjappLog.WriteToLog("Page:Da_Class-- Mehod PostRecord  in decrypt xml insert  : " + ex.Message);
                throw ex;
            }
            finally
            {
                con.Close();
            }

            return result;

        }
        #endregion


        public int InsertImpMain() //3320448
        {
            int result = 0;
            objH.hobli_code = "0";
            objH.village_code = "0";
          
            try
            {
                string Lrgdate = Convert.ToDateTime(objH.reg_date).ToString("yyyy-MM-dd");
                string qry = "SP_INSERT_IMP_Main";
                if (con.State == ConnectionState.Closed)
                    con.Open();
                SqlCommand com = new SqlCommand(qry, con);
                 com.CommandType = CommandType.StoredProcedure;
                 com.Parameters.AddWithValue("@RegNo", objH.reg_no);
                 com.Parameters.AddWithValue("@Regdate", Lrgdate);
                 com.Parameters.AddWithValue("@SROCode", objH.sro_code);
                 com.Parameters.AddWithValue("@distCode", objMain.cdist1);
                 com.Parameters.AddWithValue("@talukCode", objMain.ctaluk1);
                 com.Parameters.AddWithValue("@hobliCode", objH.hobli_code);
                 com.Parameters.AddWithValue("@villageCode", objH.village_code);

                 SqlParameter returnParameter = com.Parameters.Add("@RegistrationId", SqlDbType.Int);
                 returnParameter.Direction = ParameterDirection.ReturnValue;
                 result = com.ExecuteNonQuery();
                 objH.reg_id = (int)returnParameter.Value;
                

            }
            catch (Exception ex)
            {
                FObjappLog.WriteToLog("Page:Da_Class-- Mehod InsertImpMain Extract Xml to insert  : " + ex.Message);
                throw ex;
            }
            finally
            {
                con.Close();
            }

            return result;

        }



        #region Process xmlFile from Physical path
        public void ProcessPhysicalData()
        {
            try
            {
                string path = ConfigurationManager.AppSettings["Path"].ToString();
                string[] folders = GetPhysicalFolder();
                foreach (string foldername in folders)
                {
                    Foldername = foldername;
                    string currentpath = Path.Combine(path, foldername);
                    if (!Directory.Exists(currentpath))
                    {
                        Directory.CreateDirectory(currentpath);
                    }
                    // Remove1kbFile(@currentpath);
                    Move1kbFile(currentpath,Foldername);
                    LoadPhysicalData(@currentpath);
                }
                
            }
            catch(Exception ex)
            {
                
                FObjappLog.WriteToLog("Page Da_Class:Exception in ProcessPhysicalData Method : " + DateTime.Now + " => " + ex.ToString());
            }
            
        }
        #endregion
        
        #region this  Method not used anywhere Nandan (Created On 18-06-2022//11:45 Am)
        public void Remove1kbFile(string srcPath)
        {
            try
            {
                string destinationPath = AppDomain.CurrentDomain.BaseDirectory.ToString() + @"Unprocessed_Files\";
                //nandan Code Begin

                int count = 0;
                //string destinationPath = @"E:\SampleUnprocessedXMLFile\";
                DirectoryInfo dir = new DirectoryInfo(srcPath);
                FileInfo[] files = dir.GetFiles();
                foreach (FileInfo file in files)
                {
                    double fileSizeInBytes = file.Length;
                    double fileSizeInKb = (fileSizeInBytes / 1024);
                    if (fileSizeInKb <= 1)
                    {

                        File.Delete(file.FullName);
                        count++;
                    }
                }
                Console.WriteLine("{0} Files Deleted ", count);

                //nandan Code End
            }
            catch (Exception ex)
            {
                FObjappLog.WriteToLog("Page Da_Class:Exception in Remove1KbFile() Method : " + DateTime.Now + " => " + ex.ToString());
            }
            //nandan code End

        }
        #endregion

        #region Move 1kb file to Unprocessed_File Folder Method By Nandan (Created On 18-06-2022)
        public void Move1kbFile(string srcPath,string folderName)
        {
            try
            {
                string destinationPath = AppDomain.CurrentDomain.BaseDirectory.ToString()+@"Unprocessed_1Kb_Files\"+folderName;
                //nandan Code Begin
                if (!Directory.Exists(destinationPath))
                {
                    Directory.CreateDirectory(destinationPath);
                }
                int count = 0;
                //string destinationPath = @"E:\SampleUnprocessedXMLFile\";
                DirectoryInfo dir = new DirectoryInfo(srcPath);
                FileInfo[] files = dir.GetFiles();
                foreach (FileInfo file in files)
                {
                    double fileSizeInBytes = file.Length;
                    double fileSizeInKb = (fileSizeInBytes / 1024);
                    string fileName = Path.GetFileName(file.ToString());
                    string destFile = Path.Combine(destinationPath, fileName);
                    if (fileSizeInKb <= 1)
                    {
                        File.Move(file.FullName, destFile);
                        count++;
                    }
                }
                Console.WriteLine("{0} 1kb Files Moved into Unprocessed Folder ", count);

                //nandan Code End
            }
            catch (Exception ex)
            {
                FObjappLog.WriteToLog("Page Da_Class:Exception in Move1KbFile() Method : " + DateTime.Now + " => " + ex.ToString());
            }
        }
        //nandan code End
        #endregion
        #region Move the Transaction Roll Back Files(Exceptional File) into the Unprocessed_File Folder (By Nandan Created on 20-06-2022)
        public void MoveExceptionalFile(string srcPath,string destFolder)
        {
            try
            {
                string targetPath = AppDomain.CurrentDomain.BaseDirectory.ToString() + @"Unprocessed_Files\"+destFolder;
                //nandan Code Begin
                if (!Directory.Exists(targetPath))
                {
                    Directory.CreateDirectory(targetPath);
                }
                string filename = Path.GetFileName(srcPath);
                //string targetPath = @"E:\SampleUnprocessedXMLFile";
                string destinationFile = Path.Combine(targetPath, filename);
                if (!File.Exists(srcPath))
                {
                    FileStream fs = File.Create(srcPath);
                }
                if (File.Exists(destinationFile))
                {
                    File.Delete(destinationFile);
                }
                File.Move(srcPath, destinationFile);
                Console.WriteLine("Exceptional Files Moved into Unprocessed Folder ");

                //nandan Code End
            }
            catch (Exception ex)
            {
                FObjappLog.WriteToLog("Page Da_Class:Exception in MoveExceptionalFile() Method : " + DateTime.Now + " => " + ex.ToString());
            }
        }
        //nandan code End
        #endregion
        #region physical data
        public void LoadPhysicalData(string path)
        {
            try
            {
                 if (File.Exists(path))
                {
                   
                   // This path is a file
                    ProcessFile(path);
                }
                else if (Directory.Exists(path))
                {
                    //nandan function call to move 1kb file before processing
                    //Move1kbFile(path);
                    // This path is a directory
                    ProcessDirectory(path);
                }
                else
                {
                    FObjappLog.WriteToLog("not a valid file or directory : " + path);
                }
            }
            catch (Exception ex)
            {

                FObjappLog.WriteToLog("Page Da_Class:Exception in LoadPhysicalData Method : " + DateTime.Now + " => " + ex.ToString());
            }
        }
        #endregion

        #region Process all files in the directory passed in, recurse on any directories 
        // that are found, and process the files they contain.
        public void ProcessDirectory(string targetDirectory)
        {
           // Process the list of files found in the directory.
            string[] fileEntries = Directory.GetFiles(targetDirectory);
            
            string currentDir = targetDirectory;
            if (targetDirectory != (currentDir + "\\ProcessedFiles") && (currentDir != currentDir + "\\errorfiles"))
            {
                foreach (string fileName in fileEntries)
                {
                    if (Path.GetExtension(fileName).ToLower() == ".xml")
                    {
                        ProcessFile(fileName);
                    }
                }

                //Advance Options: - Recurse into subdirectories of this directory.
                //string[] subdirectoryEntries = Directory.GetDirectories(targetDirectory);
                //foreach (string subdirectory in subdirectoryEntries)
                // ProcessDirectory(subdirectory);
            }
        }
        #endregion

        #region Insert logic for processing found files here.
        public void OldProcessFile(string path)
        {
            //Create the XmlDocument.
            string ExmlString = "";
            string DxmlString = "";
            int j = 0;
            try
            {
                XmlDocument doc = new XmlDocument();
                doc.Load(path);

                //Display all the book titles.
                XmlNodeList elemList = doc.GetElementsByTagName("SRO");
                for (int i = 0; i < elemList.Count; i++)
                    ExmlString += elemList[i].InnerXml.ToString();

                DxmlString = DecodeMethod(ExmlString);
                DxmlString = "<?xml version=\"1.0\"?><SRO>" + DxmlString + "</SRO>";
               
            }
            catch (Exception ex)
            {
                j = 0;
            }
            finally
            {
                MoveData(path, j);
            }
        }
        #endregion

        #region once xml file is process is completed its move to some other folder
        public int MoveData(string Spath, int ProcStatus)
        {
            //string dpath = Path.GetDirectoryName(Spath);
            //dpath = Directory.GetParent(dpath) + "";
            //if (ProcStatus > 0)
            //    dpath = Directory.GetParent(dpath) + @"\ProcessedFiles";
            //if (ProcStatus < 1)
            //    dpath = Directory.GetParent(dpath) + @"\ErrorFiles";   // set errorpath

            string dpath = AppDomain.CurrentDomain.BaseDirectory.ToString();
            if (ProcStatus > 0)
                dpath = dpath + @"\ProcessedFiles";
            if (ProcStatus < 1)
                dpath = dpath + @"\ErrorFiles";   // set errorpath



            dpath = dpath + @"\" + Foldername;
            try
            {
                if (!Directory.Exists(dpath))
                {
                    Directory.CreateDirectory(dpath);
                }

                string fn = Spath;
                fn = fn.Remove(0, Directory.GetParent(Spath).ToString().Length + 1);
                string fulldpath = dpath + "\\" + fn;
                int count = 1;

                while (File.Exists(fulldpath))
                {
                    dpath = dpath + "\\Copy" + count.ToString() + "_" + fn;
                    fulldpath = dpath;
                    count++;
                }
                Directory.Move(Spath, fulldpath);
                FObjappLog.WriteToLog("MoveData() Success..: " + dpath);
            }
            catch (Exception ex)
            {
                FObjappLog.WriteToLog("Exception in MoveData() : " + ex);
            }

            return 0;
        }
        #endregion

        #region get Base64Encode string
        public string Base64Encode(string plainText)
        {
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(plainText);
            return System.Convert.ToBase64String(plainTextBytes);
        }
        #endregion

        #region decode xml data
        public string DecodeMethod(string edata)
        {
            string Ldata = null;
            try
            {
                FObjUtility = new CSUtility();
                edata = edata.Replace("\n", "");
                string dData = System.Text.Encoding.Default.GetString(Convert.FromBase64String(edata));
                FObjappLog.WriteToLog(dData);
               dData = dData.Replace("\0", "");
                dData = dData.Replace("\n", "");
                dData = dData.Replace("\r", "");
                dData = dData.Replace("\t", "");
                Ldata = FObjUtility.ConvertToUnicode(dData);
            }
            catch(Exception ex)
            {
                FObjappLog.WriteToLog("Page:Da_Class--Exception in DecodeMethod():... " + ex.Message.ToString());
            }
            
            return Ldata;
        }
        #endregion

        #region processNew data with reg id
        public int ProcessNewDataWithRID(int id)
        {
            int Rpost = 0;
            try
            {
                dt = new DataTable();
                DataSet ds = GetRecordbyid(id);
                dt = ds.Tables[0];
                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        int rid = Convert.ToInt32(dt.Rows[i]["RegistrationId"]);
                        string edata = dt.Rows[i]["JSlipData"].ToString();

                        //call the decode method
                        string dData = DecodeMethod(edata);
                        Rpost += PostRecord(edata, dData, 1, rid, 9999);  //Process New Data Uncomment after test
                    }
                }
            }
            catch(Exception ex)
            {
                FObjappLog.WriteToLog("Page:Da_Class-- Mehod ProcessNewDataWithRID()  : " + ex.Message);
            }
            
            return Rpost;
        }
        #endregion

        #region process a new data
        public int ProcessNewData()
        {
            return ProcessNewDataWithRID(1);
        }
        #endregion

        #region get xml folder from db
        public string[] GetPhysicalFolder()
        {
            string LQry = "";
            string[] FolderArr = null;
           
            DataTable gObjFolder = new DataTable();
            
            if (PTS == "T")
            {
               // LQry = "select xml_folder_path from MQS_Taluk_Info where census_dist_code=" + CDist + " and census_taluk_code=" + CTaluk + "";
            }

            if (PTS == "P")
            {
                LQry = "select xml_folder_path from MQS_Taluk_Info where BHM_WEB='Y' order by census_dist_code, census_taluk_code";
               
            }

            FObjappLog.WriteToLog("GetPhysicalFolder() con : " + JslipXMLFolder);
            try
            {
                using (SqlCommand cmd = new SqlCommand(LQry, JslipXMLFolder))
                {
                    using (SqlDataAdapter adpt = new SqlDataAdapter(cmd))
                    {
                        adpt.Fill(gObjFolder);
                    }
                }

                FolderArr = new string[gObjFolder.Rows.Count];
                for (int i = 0; i < gObjFolder.Rows.Count; i++)
                {
                    FolderArr[i] = gObjFolder.Rows[i][0].ToString();
                    FObjappLog.WriteToLog("GetPhysicalFolder() foldername : " + FolderArr[i]);
                }

            }
            catch (Exception ex)
            {
                FObjappLog.WriteToLog("GetPhysicalFolder() Ex : " + ex.ToString());
            }
            finally
            {
                gObjFolder = null;
            }
            return FolderArr;
        }
        #endregion

        #region process xml file
        public int ProcessFile(string path)
        {
            

            // int insertIntoJSlipData = 0;
            objdata.insertIntoImpMain = 0;

            System.Xml.XmlDocument doc = new System.Xml.XmlDocument();
           
            try
            {
                FObjappLog.WriteToLog("ProcessFile() path : " + path);
                doc.Load(path);
               
                DataSet ds = new System.Data.DataSet();
                ds.ReadXml(path);
                Console.WriteLine("File Name");
                Console.WriteLine(path);

                if (ds.Tables.Count > 0)
                {

                    DataTable dt2 = new DataTable();
                    dt2 = ds.Tables[1];
                   string eXML = dt2.Rows[0]["SRO_Text"].ToString();
                   

                    DataTable dt3 = new DataTable();
                    dt3 = ds.Tables[0];
                    int dst = Convert.ToInt16(dt3.Rows[0]["Dst"].ToString());

                   
                    string dXML = DecodeMethod(eXML);
                    dXML = "<Default>" + dXML + "</Default>";
                    doc.LoadXml(dXML);
                    //Console.WriteLine("---------------");
                    //Console.WriteLine(dXML);


                    XmlNodeReader xmlReader = new XmlNodeReader(doc);

                    XmlNode xmlLst = doc.ReadNode(xmlReader);

                    foreach (XmlNode node in xmlLst.ChildNodes)
                    {

                        string abc1 = node.OuterXml;
                        XmlDocument doc1 = new XmlDocument();
                        doc1.LoadXml(abc1);

                        DataSet ds1 = new System.Data.DataSet();
                        XmlNodeReader xmlReader2 = new XmlNodeReader(doc1);
                        ds1.ReadXml(xmlReader2);
                        if (ds1.Tables.Count > 0)
                        {
                            string d2XML = "<?xml version=\"1.0\"?>" + abc1;

                            Console.WriteLine("\n ProcessFile() xml decrypt successfully : ");
                            objdata.EnJslipData = eXML;
                            objdata.DcJslipData = d2XML;
                            objdata.Status ="OJP";
                            objdata.cdist = dst;

                            //commented by vidya 30-06-2020
                            //insertIntoJSlipData = PostRecord(eXML, d2XML, 0, 0, dst);
                            //if (insertIntoJSlipData > 0)
                            objdata.F_Process = "";
                            ExtractXMLfromLocal(ds, ds1, dst);

                        }
                        ds1 = null;
                        
                    }

                }


            }
            catch (Exception ex)
            {
                FObjappLog.WriteToLog("Exception in ProcessFile():... " + ex.Message.ToString());
            }
            finally
            {

               // MoveData(path, objdata.insertIntoImpMain); 
                if (objdata.F_Process != "")
                {
                     MoveData(path, objdata.insertIntoImpMain); 
                }
                else
                {
                    FObjappLog.WriteToLog("Transaction Is Rollback");
                    //nandan code start
                    Console.WriteLine("Transaction is Rollback in at line number 635");
                    //
                    string dirName = Path.GetDirectoryName(path);
                    string getFolderName=Path.GetFileName(dirName);
                    //
                    MoveExceptionalFile(path,getFolderName);
                    Console.WriteLine("File Moved inTo UnProcessed_Files Folder");
                    FObjappLog.WriteToLog("Some Files Moved into Unprocessed Folder");
                    //nandan code ends
                }
                  // Uncomment For Application 2
            }
            return objdata.insertIntoImpMain;
        }
        #endregion


        public void LoadXmlFile_old()
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(@"E:\Bhoomi\XML_Process\XML\BHM11301-ADS-01\KB_106_0301_04092021.xml");
            StreamWriter File = new StreamWriter(@"C:\Users\Vidyashree\Desktop\Text_File1.txt");
           
            XmlNodeList prop = doc.SelectNodes("SRO");

            foreach (XmlNode item in prop)
            {
                XmlNodeList prop1 = item.SelectNodes("Jslip_root");
                foreach (XmlNode item1 in prop1)
                {
                    XmlNodeList prop2 = item1.ChildNodes;
                    foreach (XmlNode item2 in prop2)
                    {
                        //foreach(Attribute attr in 
                        File.WriteLine(item2.Name);
                        File.WriteLine('\n');
                        foreach (XmlAttribute attr in item2.Attributes)
                        {
                            File.WriteLine(attr.Name);
                            File.WriteLine(" =" + attr.Value + "\n");
                        }

                        File.WriteLine('\n');
                        File.WriteLine("--------------------------------------------------------------------------");
                        File.WriteLine('\n');
                    }
                }
            }
        }

        public void LoadXmlFile()
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(@"E:\Bhoomi\XML_Process\XML\BHM11301-ADS-01\KB_106_0301_04092021.xml");
          //  StreamWriter File = new StreamWriter(@"C:\Users\Vidyashree\Desktop\Text_File1.txt");
            XmlWriter writer = XmlWriter.Create(@"C:\Users\Vidyashree\Desktop\books1.xml");


            DataSet ds = new DataSet();
            XmlNodeReader xmlReader = new XmlNodeReader(doc);

            while (xmlReader.ReadToFollowing("SRO"))
            {
                ds.ReadXml(xmlReader);
            }

            XmlNodeList prop = doc.SelectNodes("SRO");

            foreach (XmlNode item in prop)
            {
                XmlNodeList prop1 = item.SelectNodes("Jslip_root");
                foreach (XmlNode item1 in prop1)
                {
                    XmlNodeList prop2 = item1.ChildNodes;
                    foreach (XmlNode item2 in prop2)
                    {
                        //foreach(Attribute attr in 
                        writer.WriteStartElement(item2.Name);
                     
                        //File.WriteLine(item2.Name);
                        //File.WriteLine('\n');
                        foreach (XmlAttribute attr in item2.Attributes)
                        {
                            writer.WriteElementString(attr.Name, attr.Value);
                            //File.WriteLine(attr.Name);
                            //File.WriteLine(" =" + attr.Value + "\n");
                        }

                        //File.WriteLine('\n');
                        //File.WriteLine("--------------------------------------------------------------------------");
                        //File.WriteLine('\n');
                    }
                }
                writer.WriteEndElement();
                writer.Flush();
            }
        }


        public DataSet getdataset(string Path)
        {
            DataSet ds = new DataSet();

            XmlDocument doc = new XmlDocument();
            doc.Load(Path);

            XmlNodeReader xmlReader1 = new XmlNodeReader(doc);
            while (xmlReader1.ReadToFollowing("SRO"))
            {
                ds.ReadXml(xmlReader1);
            }
            XmlNodeReader xmlReader = new XmlNodeReader(doc);
            XmlNode xmlLst = doc.ReadNode(xmlReader);
            if (ds.Tables.Count > 0)
            {

               

                try
                {
                    foreach (XmlNode node in xmlLst.ChildNodes)
                    {
                        string abc1 = node.OuterXml;
                        XmlDocument doc1 = new XmlDocument();
                        doc1.LoadXml(abc1);

                        // Encrypt(doc1, "Jslip_root", key);


                        string d2XML = "<?xml version=\"1.0\"?>" + abc1;
                        string eXML = "";

                        int dst = 0301;

                        Console.WriteLine("\n ProcessFile() xml decrypt successfully : ");
                        objdata.EnJslipData = eXML;
                        objdata.DcJslipData = d2XML;
                        objdata.Status = "OJP";
                        objdata.cdist = dst;
                        objdata.F_Process = "";
                        ExtractXMLfromLocal_New(ds, dst);
                    }
                }
                catch(Exception ex)
                {
                    
                }
                
               
               
            }
           // XmlNodeReader xmlReader2 = new XmlNodeReader(doc);
            XmlNode xmlLst2 = doc.ReadNode(xmlReader);
            foreach (XmlNode node in xmlLst2.ChildNodes)
            {
                string abc1 = node.OuterXml;
                XmlDocument doc1 = new XmlDocument();
                doc1.LoadXml(abc1);

                // Encrypt(doc1, "Jslip_root", key);


                string d2XML = "<?xml version=\"1.0\"?>" + abc1;
                string eXML = "";

                int dst = 0301;

                Console.WriteLine("\n ProcessFile() xml decrypt successfully : ");
                objdata.EnJslipData = eXML;
                objdata.DcJslipData = d2XML;
                objdata.Status = "OJP";
                objdata.cdist = dst;
                objdata.F_Process = "";
                ExtractXMLfromLocal_New(ds, dst);
            }

            return ds;

        }





        #region Extract xml data for First Application
        public void ExtractXMLfromLocal(DataSet TalukDsE, DataSet TalukDs, int dst)
        {
            int cdist = dst / 100;
            int ctaluk = dst % 100;
            FObjUtility = new CSUtility();
            try
            {
                int Eicnt = TalukDsE.Tables.IndexOf("MessageHeader");

                #region physical encoded XML dataset value

                if (TalukDsE.Tables[Eicnt].ToString() == "MessageHeader")
                {

                    for (int i = 0; i < TalukDsE.Tables[Eicnt].Rows.Count; i++)
                    {
                        objMain = new jslip_imp_main();
                        objMain.src = TalukDsE.Tables[Eicnt].Rows[i]["Src"].ToString();
                        objMain.dst = TalukDsE.Tables[Eicnt].Rows[i]["Dst"].ToString();
                        objMain.XMLVersion = TalukDsE.Tables[Eicnt].Rows[i]["Version"].ToString();
                        objMain.cdist1 = cdist;
                        objMain.ctaluk1 = ctaluk;
                    }


                    Eicnt = TalukDsE.Tables.IndexOf("SRO");
                    for (int i = 0; i < TalukDsE.Tables[Eicnt].Rows.Count; i++)
                    {
                        objMain.sro_code = TalukDsE.Tables[Eicnt].Rows[i]["Code"].ToString();
                        objMain.from_date = TalukDsE.Tables[Eicnt].Rows[i]["FromDate"].ToString();
                        objMain.to_date = TalukDsE.Tables[Eicnt].Rows[i]["ToDate"].ToString();
                    }
                    Eicnt++;
                }
                #endregion
                #region physical decoded dataset value
                int ij = 0; int icnt = 0;
                icnt = TalukDs.Tables.IndexOf("Jslip_Header");
                if (TalukDs.Tables[icnt].ToString() == "Jslip_Header")
                {

                    objH = new jslip_imp_header();
                    objMain.no_of_jslip = (byte)TalukDs.Tables[icnt].Rows.Count;

                    objH.reg_no = (TalukDs.Tables[icnt].Rows[ij]["DocumentRegistrationNumber"].ToString());
                    objH.taluk_name = (TalukDs.Tables[icnt].Rows[ij]["TalukName"].ToString());
                    objH.taluk_code = (TalukDs.Tables[icnt].Rows[ij]["TalukCode"].ToString());
                    objH.hobli_name = (TalukDs.Tables[icnt].Rows[ij]["HobliName"].ToString());
                    objH.hobli_code = (TalukDs.Tables[icnt].Rows[ij]["HobliCode"].ToString());
                    objH.village_code = (TalukDs.Tables[icnt].Rows[ij]["VillageCode"].ToString());
                    objH.village_name = (TalukDs.Tables[icnt].Rows[ij]["VillageName"].ToString());
                    objH.article_name = (TalukDs.Tables[icnt].Rows[ij]["ArticleName"].ToString());
                    objH.reg_date = (TalukDs.Tables[icnt].Rows[ij]["RegistrationDate"].ToString());
                    objH.sro_name = (TalukDs.Tables[icnt].Rows[ij]["SroName"].ToString());
                    objH.sro_code = (TalukDs.Tables[icnt].Rows[ij]["SROCode"].ToString());
                    objH.cons_amount = (TalukDs.Tables[icnt].Rows[ij]["ConsiderationAmount"].ToString());
                    objH.JSlip_Status = "CJE";
                    objH.hardcopyreceived_status = "DRS";
                    objH.New_Old = "N";

                    // add by vidya 30-06-2020
                    objdata.insertIntoImpMain = InsertImpMain();
                  //  int insertIntoImpMain = InsertImpMain();


                    if (TalukDs.Tables.Contains("Jslip_Seller"))
                    {
                        icnt++;
                    }
                    #region physical encoded XML dataset value
                    itr = 0;

                    while (TalukDs.Tables[icnt].ToString() == "Jslip_Seller" || TalukDs.Tables[icnt].ToString() == "Jslip_Buyer")
                    {

                        int insertCount = 0;
                        objSB = new jslip_seller_buyer();
                        for (int i = 0; i < TalukDs.Tables[icnt].Rows.Count; i++)
                        {
                           
                            objSB.total_area = (TalukDs.Tables[icnt].Rows[i]["TotalArea"].ToString());
                            
                            objSB.reg_no = (TalukDs.Tables[icnt].Rows[i]["DocumentRegistrationNumber"].ToString());
                            objSB.prop_no = (TalukDs.Tables[icnt].Rows[i]["PropertyNumber"].ToString());
                            objSB.survey_no = (TalukDs.Tables[icnt].Rows[i]["SurveyNo"].ToString());
                            objSB.surnoc = FObjUtility.GetIsfoc(TalukDs.Tables[icnt].Rows[i]["surnoc"].ToString());
                            objSB.hissa_no = FObjUtility.GetIsfoc(TalukDs.Tables[icnt].Rows[i]["HissaNo"].ToString());

                            objSB.unit_of_measure = (TalukDs.Tables[icnt].Rows[i]["UnitofMeasure"].ToString());
                            objSB.party_no = (TalukDs.Tables[icnt].Rows[i]["PartyNo"].ToString());
                            objSB.party_name = FObjUtility.GetIsfoc(TalukDs.Tables[icnt].Rows[i]["PartyName"].ToString());

                            //start added by vidya 12-04-2020(Jslip_index_owner table check owner column length)
                            if (objSB.party_name.Length > 200)
                            {
                                objSB.party_name = objSB.party_name.Substring(0, 200);
                            }
                            //end


                            objSB.fat_hus_name = (TalukDs.Tables[icnt].Rows[i]["Fat_Hus_Name"].ToString());
                            objSB.address = (TalukDs.Tables[icnt].Rows[i]["Address"].ToString());
                            objSB.GPA_name = (TalukDs.Tables[icnt].Rows[i]["GPAName"].ToString());
                            objSB.joint_with_prev = (TalukDs.Tables[icnt].Rows[i]["JointWithPrev"].ToString());
                            objSB.liabilities = (TalukDs.Tables[icnt].Rows[i]["LiabilitiesDetails"].ToString());
                            
                            #region call insertion method
                            itr++;
                            insertCount = MethodInsert(itr);
                            if (insertCount < 0)
                                insertCount = 10;//break for loop
                            #endregion
                        }
                        icnt++;
                        if (icnt >= TalukDs.Tables.Count)
                        {
                            icnt = TalukDs.Tables.IndexOf("Jslip_Header");
                            break;
                        }
                    }
                    #endregion


                }
                #endregion


            }
           
            catch (Exception ex)
            {
                FObjappLog.WriteToLog("Exception in ExtractXMLfromLocal: " + ex.Message.ToString());
            }
            finally
            {
                
            }

        }
        #endregion

        #region push data to all table
        public int MethodInsert(int p)
        {
            string QjsHead = "";
            string QjsMain = "";
            string QjsOwner = "";
            string QjsConfirm = "";
            string Qjsdata = "";
            SqlTransaction trans = null;
            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                trans = con.BeginTransaction();
                if (p < 2)
                {
                    //string QgetReg = @"select max(RegistrationID) from jslip_data";
                    //if (con.State == ConnectionState.Closed)
                    //    con.Open();

                    //using (SqlCommand cmd1 = new SqlCommand(QgetReg, con, trans))
                    //{
                    //    objH.reg_id = Convert.ToInt32(cmd1.ExecuteScalar());
                    //}
                    //con.Close();
                }
                objH.hobli_code = "0";
                objH.village_code = "0";
                string rgdate = Convert.ToDateTime(objH.reg_date).ToString("yyyy-MM-dd");
                QjsHead = @"INSERT INTO [Jslip_index_head]
([RegistrationId],[census_dist_code],[census_taluk_code],[hobli_code],[village_code],[land_code],[survey_no],[surnoc],[hissa_no]) 
VALUES (" + objH.reg_id + "," + objMain.cdist1 + "," + objMain.ctaluk1 + "," + objH.hobli_code + "," + objH.village_code + ",0," + objSB.survey_no + ",'" + objSB.surnoc + "','" + objSB.hissa_no + "');";

//                QjsMain = @"INSERT INTO [Jslip_index_main]
//([RegistrationId],[RegistrationNo],[RegistrationDate],[ReceivedDate],[SROCode],[previousarticlecode],[previousregistrationno]
//,[previousregistrationdate],[ArticleCode],[SRO_RegId],[census_dist_code],[census_taluk_code],[hobli_code],[village_code]
//,[Confirmed],[ConfirmedOn])
//VALUES (" + objH.reg_id + ",'" + objH.reg_no + "','" + rgdate + "',NULL,'" + objH.sro_code + "',null,null"
//              + ",null,null,null," + objMain.cdist1 + "," + objMain.ctaluk1 + "," + objH.hobli_code + "," + objH.village_code + ",'N',null)";

                 //Insert into jslipdata
                 int cdist = (objdata.cdist) / 100;
                 int ctaluk = (objdata.cdist) % 100;
                 string  status = "OLD";
                 Qjsdata = "USP_Add_OldData";
               
                //-------------------


                QjsConfirm = @"INSERT INTO [Jslips_Confirmed]
([SRO_RegId],[census_dist_code],[census_taluk_code],[hobli_code],[village_code],[Confirmed],[ConfirmedOn])
Values (" + objH.reg_id + "," + objMain.cdist1 + "," + objMain.ctaluk1 + "," + objH.hobli_code + "," + objH.village_code + ",'N',null);";


                // begin commented by vidya 23-08-2021
                //  QjsOwner = @"INSERT INTO [Jslip_index_owner]
                //([RegistrationId],[census_dist_code],[census_taluk_code],[hobli_code],[village_code],[land_code]
                //,[owner_no],[main_owner_no],[owner],[sold_ext_acre],[sold_ext_gunta],[sold_ext_fgunta])
                //Values (" + objH.reg_id + "," + objMain.cdist1 + "," + objMain.ctaluk1 + "," + objH.hobli_code + "," + objH.village_code + ",0,"
                //            + objSB.party_no + ",0,N'" + objSB.party_name + "',0,0,null);";
                //end

                QjsOwner = @"INSERT INTO [Jslip_index_owner]([RegistrationId],[census_dist_code],[census_taluk_code],[hobli_code],[village_code],[land_code],[owner_no],[main_owner_no],[owner],[sold_ext_acre],[sold_ext_gunta],[sold_ext_fgunta])
                Values (@reg_id,@cdist1,@ctaluk1,@hobli_code,@village_code,0,@party_no,0,@party_name,0,0,null);";

                

                //registration ID might be here sro_regID

                if (con.State == ConnectionState.Closed)
                    con.Open();

                if (p < 2)
                {

                    using (SqlCommand cmd2 = new SqlCommand(QjsHead, con, trans))
                    {
                       // cmd2.Transaction = trans;
                        int a = cmd2.ExecuteNonQuery();
                    }

                    using (SqlCommand cmd4 = new SqlCommand(QjsConfirm, con, trans))
                    {
                        //cmd4.Transaction = trans;
                        int ac = cmd4.ExecuteNonQuery();
                    }

                    using (SqlCommand cmd3 = new SqlCommand(Qjsdata, con, trans))
                    {
                        //cmd3.Transaction = trans;
                        cmd3.CommandType = CommandType.StoredProcedure;
                        cmd3.Parameters.AddWithValue("@EnJslipData", objdata.EnJslipData);
                        cmd3.Parameters.AddWithValue("@talukStatus", "OJD");
                        cmd3.Parameters.AddWithValue("@CDist", cdist);
                        cmd3.Parameters.AddWithValue("@CTaluk", ctaluk);
                        cmd3.Parameters.AddWithValue("@DcJslipData", objdata.DcJslipData);
                        cmd3.Parameters.AddWithValue("@Status", @status);
                        cmd3.Parameters.AddWithValue("@RegistrationID", objH.reg_id);   //@CDist, @CTaluk

                        // result = com.ExecuteNonQuery();
                        int ab = cmd3.ExecuteNonQuery();
                    }
                }
                // begin commented by vidya 23-08-2021
                //using (SqlCommand cmd5 = new SqlCommand(QjsOwner, con, trans))
                //{
                //    //cmd5.Transaction = trans;
                //    int a = cmd5.ExecuteNonQuery();
                //}
                //end

                using (SqlCommand cmd5 = new SqlCommand(QjsOwner, con, trans))
                {
                    cmd5.Parameters.AddWithValue("@reg_id", objH.reg_id);
                    cmd5.Parameters.AddWithValue("@cdist1", objMain.cdist1);
                    cmd5.Parameters.AddWithValue("@ctaluk1", objMain.ctaluk1);
                    cmd5.Parameters.AddWithValue("@hobli_code", objH.hobli_code);
                    cmd5.Parameters.AddWithValue("@village_code", objH.village_code);
                    cmd5.Parameters.AddWithValue("@party_no", objSB.party_no);
                    cmd5.Parameters.AddWithValue("@party_name", objSB.party_name);
                    int a = cmd5.ExecuteNonQuery();
                }


                trans.Commit();
                objdata.F_Process = "done";

                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            catch (Exception ex)
            {
                trans.Rollback();
                trans.Dispose();
                trans = null;
                objdata.F_Process = "";

                string Lquery = "delete from Jslip_Index_Main where RegistrationId=" + objH.reg_id + " ";
                using (SqlCommand cmd = new SqlCommand(Lquery, con))
                {
                    int del = cmd.ExecuteNonQuery();

                }
                FObjappLog.WriteToLog("delete the Record in Jslip_imp_Main with RegNo:"+objH.reg_id);
                FObjappLog.WriteToLog("Exception in MethodInsert : " + ex.Message.ToString());
                return 0;
            }
            return 1;
        }
        #endregion

        #region xml string to dataset
        public DataSet XmlStringtoDS(string str)
        {
            DataSet ds1 = new System.Data.DataSet();
            try
            {
                XmlDocument doc1 = new XmlDocument();
                doc1.LoadXml(str);
                XmlNodeReader xmlReader2 = new XmlNodeReader(doc1);
                ds1.ReadXml(xmlReader2);
                return ds1;

            }
            catch (Exception ex)
            {
                FObjappLog.WriteToLog("Error in XmlStringtoDS() :" + ex);
            }
            return ds1;
        }
        #endregion

        public void ExtractXMLfromLocal_New(DataSet TalukDs, int dst)
        {
            int cdist = dst / 100;
            int ctaluk = dst % 100;
            FObjUtility = new CSUtility();
            try
            {
                
                int Eicnt = TalukDs.Tables.IndexOf("SRO");
                for (int i = 0; i < TalukDs.Tables[Eicnt].Rows.Count; i++)
                {
                    objMain.sro_code = TalukDs.Tables[Eicnt].Rows[i]["Code"].ToString();
                    objMain.from_date = TalukDs.Tables[Eicnt].Rows[i]["FromDate"].ToString();
                    objMain.to_date = TalukDs.Tables[Eicnt].Rows[i]["ToDate"].ToString();
                    objMain.cdist1 = cdist;
                    objMain.ctaluk1 = ctaluk;
                }

                #region physical decoded dataset value
                int ij = 0; int icnt = 0;
                icnt = TalukDs.Tables.IndexOf("Jslip_Header");
                if (TalukDs.Tables[icnt].ToString() == "Jslip_Header")
                {

                    objH = new jslip_imp_header();
                    objMain.no_of_jslip = (byte)TalukDs.Tables[icnt].Rows.Count;

                    objH.reg_no = (TalukDs.Tables[icnt].Rows[ij]["DocumentRegistrationNumber"].ToString());
                    objH.taluk_name = (TalukDs.Tables[icnt].Rows[ij]["TalukName"].ToString());
                    objH.taluk_code = (TalukDs.Tables[icnt].Rows[ij]["TalukCode"].ToString());
                    objH.hobli_name = (TalukDs.Tables[icnt].Rows[ij]["HobliName"].ToString());
                    objH.hobli_code = (TalukDs.Tables[icnt].Rows[ij]["HobliCode"].ToString());
                    objH.village_code = (TalukDs.Tables[icnt].Rows[ij]["VillageCode"].ToString());
                    objH.village_name = (TalukDs.Tables[icnt].Rows[ij]["VillageName"].ToString());
                    objH.article_name = (TalukDs.Tables[icnt].Rows[ij]["ArticleName"].ToString());
                    objH.reg_date = (TalukDs.Tables[icnt].Rows[ij]["RegistrationDate"].ToString());
                    objH.sro_name = (TalukDs.Tables[icnt].Rows[ij]["SroName"].ToString());
                    objH.sro_code = (TalukDs.Tables[icnt].Rows[ij]["SROCode"].ToString());
                    objH.cons_amount = (TalukDs.Tables[icnt].Rows[ij]["ConsiderationAmount"].ToString());
                    objH.JSlip_Status = "CJE";
                    objH.hardcopyreceived_status = "DRS";
                    objH.New_Old = "N";

                    // add by vidya 30-06-2020
                    objdata.insertIntoImpMain = InsertImpMain();
                    //  int insertIntoImpMain = InsertImpMain();


                    if (TalukDs.Tables.Contains("Jslip_Seller"))
                    {
                        icnt++;
                    }
                    #region physical encoded XML dataset value
                    itr = 0;

                    while (TalukDs.Tables[icnt].ToString() == "Jslip_Seller" || TalukDs.Tables[icnt].ToString() == "Jslip_Buyer")
                    {

                        int insertCount = 0;
                        objSB = new jslip_seller_buyer();
                        for (int i = 0; i < TalukDs.Tables[icnt].Rows.Count; i++)
                        {

                            objSB.total_area = (TalukDs.Tables[icnt].Rows[i]["TotalArea"].ToString());

                            objSB.reg_no = (TalukDs.Tables[icnt].Rows[i]["DocumentRegistrationNumber"].ToString());
                            objSB.prop_no = (TalukDs.Tables[icnt].Rows[i]["PropertyNumber"].ToString());
                            objSB.survey_no = (TalukDs.Tables[icnt].Rows[i]["SurveyNo"].ToString());
                            objSB.surnoc = FObjUtility.GetIsfoc(TalukDs.Tables[icnt].Rows[i]["surnoc"].ToString());
                            if (objSB.surnoc == "ERROR Index was outside the bounds of the array.")
                            {
                                objSB.surnoc = FObjUtility.GetIsfoc(TalukDs.Tables[icnt].Rows[i]["surnoc"].ToString());
                            }

                            objSB.hissa_no = FObjUtility.GetIsfoc(TalukDs.Tables[icnt].Rows[i]["HissaNo"].ToString());

                            if (objSB.hissa_no == "ERROR Index was outside the bounds of the array.")
                            {
                                objSB.hissa_no = FObjUtility.GetIsfoc(TalukDs.Tables[icnt].Rows[i]["HissaNo"].ToString());
                            }

                            objSB.unit_of_measure = (TalukDs.Tables[icnt].Rows[i]["UnitofMeasure"].ToString());
                            objSB.party_no = (TalukDs.Tables[icnt].Rows[i]["PartyNo"].ToString());
                            objSB.party_name = FObjUtility.GetIsfoc(TalukDs.Tables[icnt].Rows[i]["PartyName"].ToString());
                            if(objSB.party_name =="ERROR Index was outside the bounds of the array.")
                            {
                                objSB.party_name = TalukDs.Tables[icnt].Rows[i]["PartyName"].ToString();
                            }
                            //start added by vidya 12-04-2020(Jslip_index_owner table check owner column length)
                            if (objSB.party_name.Length > 200)
                            {
                                objSB.party_name = objSB.party_name.Substring(0, 200);
                            }
                            //end


                            objSB.fat_hus_name = (TalukDs.Tables[icnt].Rows[i]["Fat_Hus_Name"].ToString());
                            objSB.address = (TalukDs.Tables[icnt].Rows[i]["Address"].ToString());
                            objSB.GPA_name = (TalukDs.Tables[icnt].Rows[i]["GPAName"].ToString());
                            objSB.joint_with_prev = (TalukDs.Tables[icnt].Rows[i]["JointWithPrev"].ToString());
                            objSB.liabilities = (TalukDs.Tables[icnt].Rows[i]["LiabilitiesDetails"].ToString());

                            #region call insertion method
                            itr++;
                            insertCount = MethodInsert(itr);
                            if (insertCount < 0)
                                insertCount = 10;//break for loop
                            #endregion
                        }
                        icnt++;
                        if (icnt >= TalukDs.Tables.Count)
                        {
                            icnt = TalukDs.Tables.IndexOf("Jslip_Header");
                            break;
                        }
                    }
                    #endregion


                }
                #endregion


            }

            catch (Exception ex)
            {
                FObjappLog.WriteToLog("Exception in ExtractXMLfromLocal: " + ex.Message.ToString());
            }
            finally
            {

            }

        }


      

        public static void Encrypt(XmlDocument Doc, string ElementName, SymmetricAlgorithm Key)
        {
            // Check the arguments.
            if (Doc == null)
                throw new ArgumentNullException("Doc");
            if (ElementName == null)
                throw new ArgumentNullException("ElementToEncrypt");
            if (Key == null)
                throw new ArgumentNullException("Alg");

            ////////////////////////////////////////////////
            // Find the specified element in the XmlDocument
            // object and create a new XmlElement object.
            ////////////////////////////////////////////////
            XmlElement elementToEncrypt = Doc.GetElementsByTagName(ElementName)[0] as XmlElement;
            // Throw an XmlException if the element was not found.
            if (elementToEncrypt == null)
            {
                throw new XmlException("The specified element was not found");
            }

            //////////////////////////////////////////////////
            // Create a new instance of the EncryptedXml class
            // and use it to encrypt the XmlElement with the
            // symmetric key.
            //////////////////////////////////////////////////

            EncryptedXml eXml = new EncryptedXml();

            byte[] encryptedElement = eXml.EncryptData(elementToEncrypt, Key, false);
            ////////////////////////////////////////////////
            // Construct an EncryptedData object and populate
            // it with the desired encryption information.
            ////////////////////////////////////////////////

            EncryptedData edElement = new EncryptedData();
            edElement.Type = EncryptedXml.XmlEncElementUrl;

            // Create an EncryptionMethod element so that the
            // receiver knows which algorithm to use for decryption.
            // Determine what kind of algorithm is being used and
            // supply the appropriate URL to the EncryptionMethod element.

            string encryptionMethod = null;

            if (Key is Aes)
            {
                encryptionMethod = EncryptedXml.XmlEncAES256Url;
            }
            else
            {
                // Throw an exception if the transform is not AES
                throw new CryptographicException("The specified algorithm is not supported or not recommended for XML Encryption.");
            }

            edElement.EncryptionMethod = new EncryptionMethod(encryptionMethod);

            // Add the encrypted element data to the
            // EncryptedData object.
            edElement.CipherData.CipherValue = encryptedElement;

            ////////////////////////////////////////////////////
            // Replace the element from the original XmlDocument
            // object with the EncryptedData element.
            ////////////////////////////////////////////////////
           
           EncryptedXml.ReplaceElement(elementToEncrypt, edElement, false);
        }
    }
}
