﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace XML_1stProcess
{
    class Jslip_data
    {
        public int cdist { get; set; }
        public int ctaluk { get; set; }

        public string EnJslipData { get; set; }
        public string DcJslipData { get; set; }
        public string Status { get; set; }
        public string RegistrationID { get; set; }
        public string talukStatus { get; set; }

        public string F_Process { get; set; }

        public int insertIntoImpMain { get; set; }
    }
}
